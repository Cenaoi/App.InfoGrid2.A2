﻿

Mini2.define('Mini2.ui.form.Base', {

    

});