﻿/// <reference path="/Core/Scripts/jquery/jquery-1.4.1-vsdoc.js" />
/// <reference path="../../define.js" />



Mini2.define('Mini2.ui.form.field.Password', {

    extend: 'Mini2.ui.form.field.Text',

    alias: 'widget.password',
    type:'password'


});