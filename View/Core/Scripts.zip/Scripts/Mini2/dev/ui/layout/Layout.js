﻿

/// <reference path="../Mini.js" />
/// <reference path="../../../jquery/jquery-1.4.1-vsdoc.js" />



Mini2.define("Mini2.ui.layout.Layout", {

    

});