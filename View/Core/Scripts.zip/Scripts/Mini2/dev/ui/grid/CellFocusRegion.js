﻿
/**
* 单元格的焦点框
* 
*/
Mini2.define('Mini2.ui.grid.CellFocusRegion', {



});