﻿/// <reference path="../jquery/jquery-1.4.1-vsdoc.js" />
/// <reference path="Widget.js" />


Mini.ui.EcForm = function (sender) {

    var widget = new Mini.ui.Widget();

    return widget;

}

window.EcForm = Mini.ui.EcForm;