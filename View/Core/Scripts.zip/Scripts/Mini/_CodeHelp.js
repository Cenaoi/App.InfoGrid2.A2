﻿
/// <reference path="_Default.js" />
/// <reference path="Widget.js" />

var widget1 = new Mini.ui.Widget();