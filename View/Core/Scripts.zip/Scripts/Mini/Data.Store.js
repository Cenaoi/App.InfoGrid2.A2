﻿

Mini.Data.Store = function () {

    

});